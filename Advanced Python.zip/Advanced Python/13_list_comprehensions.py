mylist = [1,23,56,66,9,5]

# squaredList = []
# for item in mylist:
#     squaredList.append(item*item)


sqauredList = [i*i for i in mylist]

print(sqauredList)