try:
    a = int(input("Enter the number : "))
    print(a)

except ValueError as v:
    print("hey")
    print(v)


except Exception as e:
    print(e)

print("hello")