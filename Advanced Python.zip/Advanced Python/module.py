def myFun():
    print("Hello World")



if __name__ == "__main__":
    # if this code is directly executed by running the file its present in 
    print("we are running the code")
    myFun()
    print(__name__)  # agar uski file ko run kar rahe ho toh __ main __ file dikhega
