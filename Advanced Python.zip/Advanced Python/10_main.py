from module import myFun

# yaha pe module run dikhega


