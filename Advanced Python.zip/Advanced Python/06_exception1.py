try:
	# Code that might raise an exception
	pass
except ZeroDivisionError:
	# Handle division by zero error
	print("Cannot divide by zero.")
except TypeError:
	# Handle type error
	print("Invalid type encountered.")
except:
	# Handle all other exceptions
	print("An unexpected error occurred.")