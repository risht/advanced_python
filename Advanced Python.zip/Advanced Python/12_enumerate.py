l = [3,4,5,89,100]

# index =  0
# for r in l:
 
#     print(f"The item in {index} is {r}")
#     index+=1

# Enumerate function

for index,item in enumerate(l):
    print(f"The item numebr in {index} is {item}")