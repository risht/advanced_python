n : int = 5

name: str = "ruis1"


def sum(a:int, b:int) ->int:
    return a+b

