a = 89

def fun():

    #global a # gloabal keyword changes the global variable

    a = 3

    print(a)



fun()
print(a)