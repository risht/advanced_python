def main():
    try:
        a = int(input("Enter the number: "))
        print(a)
        return

    except Exception as e:
        print("hey")
        print(e)

    finally: # it will run any how
        print("I am inside the finally block")

main()


