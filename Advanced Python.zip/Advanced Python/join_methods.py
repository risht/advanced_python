a = ["Harry","Rohan","Shubham"]

result = ":: and, ".join(a)
print(result)