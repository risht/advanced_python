a = int(input("Enter the number :"))
b = int(input("Enter the second number :"))


if(b==0):
    raise ZeroDivisionError("Programm is not meant to divide by 0")

else:
    print(f"The div is {a/b}")


    