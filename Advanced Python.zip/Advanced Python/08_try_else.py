try:
    a = int(input("Enter the number : "))
    print(a)


except Exception as e:
    print("hey")
    print(e)


else:
    print("I am inside the else block")


