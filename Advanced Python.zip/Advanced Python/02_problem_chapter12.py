l = [1,5,7,90,4,67,34]

for i,item in enumerate(l):
    if i == 2 or i ==4 or i==6:
        print(item) 